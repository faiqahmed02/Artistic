import { LinearGradient } from "expo-linear-gradient";
import React from "react";

function ViewAllProducts() {
  return (
    <View>
      <LinearGradient>ViewAllProducts</LinearGradient>
    </View>
  );
}

export default ViewAllProducts;
